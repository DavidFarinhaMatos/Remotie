const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(`mongodb+srv://DavidMatos:Roger857@cluster0.pf5tuj3.mongodb.net/Remotie?retryWrites=true&w=majority`, () => {
    console.log('connected to mongodb')
})